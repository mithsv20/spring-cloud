package com.inn.product.RatingData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatingDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
