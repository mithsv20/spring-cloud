package com.inn.product.MovieCatelog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieCatelogApplicationTests {

	@Test
	void contextLoads() {
	}

}
