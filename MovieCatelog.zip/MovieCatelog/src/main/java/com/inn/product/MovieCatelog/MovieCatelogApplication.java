package com.inn.product.MovieCatelog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieCatelogApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieCatelogApplication.class, args);
	}

}
