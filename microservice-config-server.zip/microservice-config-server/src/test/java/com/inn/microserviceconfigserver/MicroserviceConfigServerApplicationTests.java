package com.inn.microserviceconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
